function Out = ImVar(I,r)
%   Calculate the neighbourhood variance of each pixel in I at (2*r+1)*(2*r+1) window.
%   Code Author: Fei KOU
%   Email: koufei@hotmail.com
%   Date: 12/2/2014

    [M,N,n] = size(I);
    Out = double(zeros(M,N,n));
    
    for k = 1:n
        for i = 1:M    
                for j = 1:N
                    xlow = max (1,(i-r));
                    xupp = min (M,(i+r));
                    ylow = max (1,j-r);
                    yupp = min (N,j+r);
                    S1=0;
                    S2=0;
                    S3=0;
                    for ii=xlow:xupp
                        for jj=ylow:yupp
                            S1=S1+I(ii,jj,k);
                            S2=S2+I(ii,jj,k)^2;
                            S3=S3+1;
                        end
                    end
                    S1=S1/S3;
                    S2=S2/S3;
                    Out(ii,jj,k) = S2-S1^2;
                end
        end
    end