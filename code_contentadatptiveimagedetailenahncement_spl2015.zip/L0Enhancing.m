function S = L0Enhancing(Im, eta, lambda, kappa)
%   Code for
%   [1] "Content Adaptive Image Detail Enhancement," Fei Kou, Weihai Chen, Zhengguo Li, and Changyun Wen, 
%   IEEE Signal Processing Letters, vol. 22, no. 2, pp. 211-215, 2015.

%   Code Author: Fei KOU
%   Email: koufei@hotmail.com
%   Date: 12/2/2014
%   Modified from the code provied by Li Xu et. al. for their paper 
%   [2] "Image Smoothing via L0 Gradient Minimization", Li Xu, Cewu Lu, Yi Xu, Jiaya Jia, ACM Transactions on Graphics, 
%   (SIGGRAPH Asia 2011), 2011. 
%  
%   The code and the algorithm are for non-comercial use only.

%   Paras: 
%   @Im    : Input UINT8 image, both grayscale and color images are acceptable.
%   @eta :   Parameter controlling how many times of detail adding to the
%            input image
%   @lambda: Smoothing parameter controlling the degree of enhance. 
%            Typically it is within the range [1e-3, 1e-1], 2e-2 by default.
%   @kappa : Parameter that controls the rate. 
%            Small kappa results in more iteratioins and with sharper edges.   
%            We select kappa in (1, 2].    
%            kappa = 2 is suggested for natural images.  
%
%   Example
%   ==========
%   Im  = imread('pflower.jpg');
%   S  = L0Enhancing(Im); % Default Parameters (lambda = 2e-2, kappa = 2)
%   figure, imshow(Im), figure, imshow(S);

if ~exist('eta','var')
    kappa = 4;
end
if ~exist('kappa','var')
    kappa = 2.0;
end
if ~exist('lambda','var')
    lambda = 2e-2;
end
S = im2double(Im);
[N,M,D] = size(Im);
Ix = [diff(S,1,2), S(:,1,:) - S(:,end,:)];
Iy = [diff(S,1,1); S(1,:,:) - S(end,:,:)];

Ixy2 =ImVar(S,1); %variance of 3*3 neighbour

for k = 1:D
minDd = min(min(Ixy2(:,:,k)));
meanDd = mean(mean(Ixy2(:,:,k)));
alpha = meanDd; 
kk = log(0.01)/(minDd-alpha);
u(:,:,k) = 1-1./(1+exp(kk*(Ixy2(:,:,k)-alpha))); %weight calculated with Sigmoid function
end

betamax = 1e5;
fx = [1, -1];
fy = [1; -1];
sizeI2D = [N,M];
otfFx = psf2otf(fx,sizeI2D);
otfFy = psf2otf(fy,sizeI2D);
Normin1 = fft2(S);
Denormin2 = abs(otfFx).^2 + abs(otfFy ).^2;
if D>1
    Denormin2 = repmat(Denormin2,[1,1,D]);
end
beta = 2*lambda;
while beta < betamax
    Denormin = 1 + beta*Denormin2;
    % h-v subproblem
    h = [diff(S,1,2), S(:,1,:) - S(:,end,:)] - (eta+1 - eta*u) .* Ix ;
    v = [diff(S,1,1); S(1,:,:) - S(end,:,:)] - (eta+1 - eta*u) .* Iy;
    if D==1
        t = (h.^2+v.^2)<eta^2*lambda/beta;
    else
        t = sum((h.^2+v.^2),3)<eta^2*lambda/beta;
        t = repmat(t,[1,1,D]);
    end
    h(t)=0; v(t)=0;
    h = h + (eta+1 - eta*u) .* Ix;
    v = v + (eta+1 - eta*u) .* Iy;
    
    % S subproblem
    Normin2 = [h(:,end,:) - h(:, 1,:), -diff(h,1,2)];
    Normin2 = Normin2 + [v(end,:,:) - v(1, :,:); -diff(v,1,1)];
    FS = (Normin1 + beta*fft2(Normin2))./Denormin;
    S = real(ifft2(FS));
    beta = beta*kappa;
    fprintf('.');
end
fprintf('\n');
end
