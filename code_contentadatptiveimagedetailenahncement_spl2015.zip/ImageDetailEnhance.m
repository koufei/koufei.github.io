Im = imread('tulips.bmp');

lambda = 0.16; %Largrange factor
k = 4;  %Detail amplify time


E = L0Enhancing(Im, k, lambda/(k^2));
figure('Name','Enhanced image'), imshow(E,'Border','tight');
imwrite(E,'Enhanced_tulips.png','png'); 

